================================================================================
Thỏa thuận cấp phép
================================================================================

Thỏa thuận cấp phép cho phần mềm này (sau đây được gọi là PHẦN MỀM), được định
rõ như sau.

1. Các quyền sở hữu trí tuệ đối với PHẦN MỀM luôn thuộc về Công ty TNHH 
   FUJIFILM Business Innovation (sau đây được nhắc đến là 
   FUJIFILM Business Innovation) cũng như các tác giả bản quyền gốc.

2. PHẦN MỀM chỉ có thể được sử dụng chung với các sản phẩm tương thích của
   FUJIFILM Business Innovation (sau đây được gọi là CÁC SẢN PHẨM TƯƠNG THÍCH)
   tại quốc gia mà bạn mua CÁC SẢN PHẨM TƯƠNG THÍCH đó.

3. Bạn phải tuân theo các lưu ý và giới hạn (sau đây được gọi là LƯU Ý VÀ GIỚI HẠN)
   được FUJIFILM Business Innovation công bố trong khi sử dụng PHẦN MỀM.

4. Bạn không được phép sửa đổi, chỉnh sửa, thực hiện kỹ thuật đảo ngược,
   dịch ngược hay tách rời toàn bộ hay bất kỳ phần nào của
   PHẦN MỀM cho mục đích phân tích PHẦN MỀM.

5. Bạn không được phép phân phối PHẦN MỀM trên mạng lưới thông tin liên lạc hay
   chuyển nhượng, bán, cho thuê hoặc cấp phép PHẦN MỀM đến bất kỳ bên thứ ba nào
   bằng cách chép lại PHẦN MỀM trên bất kỳ phương tiện ghi nào như đĩa mềm hay
   băng từ (băng ghi âm).

6. FUJIFILM Business Innovation, các đối tác kênh của FUJIFILM Business Innovation,
   các đại lý được ủy quyền và các tác giả bản quyền gốc của
   PHẦN MỀM sẽ không chịu trách nhiệm cho bất kỳ tổn
   thất hoặc thiệt hại nào phát sinh từ việc kết hợp với phần cứng hay chương
   trình không được liệt kê trong phần LƯU Ý VÀ GIỚI HẠN của PHẦN MỀM, hoặc từ
   bất kỳ sự chỉnh sửa nào của PHẦN MỀM.

7. FUJIFILM Business Innovation, các đối tác kênh của FUJIFILM Business Innovation,
   các đại lý được ủy quyền và các tác giả bản quyền gốc của
   PHẦN MỀM sẽ không chịu trách nhiệm cho bất kỳ bảo
   hành hoặc khoản đền bù nào liên quan đến PHẦN MỀM.

================================================================================
PCL 6 Print Driver Ver.6.12.4 Thông tin bổ sung cho trình điều khiển
================================================================================

Tài liệu này cung cấp thông tin bổ sung về trình điều khiển ở
các mục sau:

1. Các sản phẩm phần cứng đích
2. Yêu cầu
3. Chú thích chung
4. LƯU Ý VÀ GIỚI HẠN
5. Cập nhật phần mềm

---------------------------------------------------
1. Các sản phẩm phần cứng đích
---------------------------------------------------
PrimeLink C9070
PrimeLink C9065

---------------------------------------------------
2. Yêu cầu
---------------------------------------------------
Vui lòng lưu ý rằng trình điều khiển in này
hoạt động trên máy tính chạy hệ điều hành sau đây.

  Microsoft(R) Windows Server(R) 2012
  Microsoft(R) Windows Server(R) 2012 R2
  Microsoft(R) Windows(R) 10 x64 Editions
  Microsoft(R) Windows Server(R) 2016
  Microsoft(R) Windows Server(R) 2019
  Microsoft(R) Windows(R) 11
  Microsoft(R) Windows Server(R) 2022

  Vui lòng truy cập trang web của chúng tôi để xem các hệ điều hành được hỗ trợ và phần mềm mới nhất.

* Tương ứng với việc đổi tên của công ty.
  Không thể tiếp quản thiết đặt trình điều khiển do bạn không thể cập nhật trình điều khiển từ phiên bản cũ hơn. Hãy xóa hết và cài lại trình điều khiển mới từ đầu. 

---------------------------------------------------
3. Chú thích chung
---------------------------------------------------
* Đóng tất cả các ứng dụng đang hoạt động trước khi cài đặt
  trình điều khiển in.

* Luôn khởi động lại máy tinh sau khi cài đặt một phiên bản nâng cấp
  của trình điều khiển in.

* Nếu bạn đã xóa một phiên bản cũ hơn của trình điều khiển in,
  hãy luôn khởi động lại máy tính trước khi cài đặt phiên bản mới.

* Một số ứng dụng cung cấp các tùy chọn in liên quan đến
  số lượng bản sao và bản sao được chia bộ.  Luôn chọn
  các tùy chọn in trong ứng dụng trừ khi có các hướng dẫn
  cụ thể khác. Sử dụng các hộp thoại trình điều khiển in để chọn
  các tùy chọn nâng cao như: In 2 mặt, Bộ mẫu hoặc các
  tùy chọn không sẵn dùng trong ứng dụng.

* Luôn đóng các hộp thoại của trình điều khiển in và/hoặc hộp thoại In
  của ứng dụng trước khi bạn thực hiện những thay đổi cho thiết đặt
  mặc định của trình điều khiển in trên Bảng điều khiển.

* Nếu giấy ra offset của công việc không thực hiện tốt với các
  bản sao được chia bộ, bạn có thể thử bỏ chọn tùy chọn
  "Chia bộ" trong ứng dụng và chọn hộp kiểm "Chia bộ" trong
  trình điều khiển in.

* Đối với quá trình cài đặt thông qua mạng,
  nếu bạn nhấp chuột phải vào thư mục [Máy in], hãy đến mục
  [Chạy với vai trò người quản trị] từ menu và chọn [Thêm máy in...],
  biểu tượng máy in có thể sẽ không được tạo.

* Việc đổi tên biểu tượng máy in cần phải tuân theo quy ước đặt tên tệp của HĐH. Sử dụng
  các biểu tượng hoặc ký tự đặc biệt có thể phát sinh lỗi đổi tên hoặc hoạt động
  không mong muốn của trình điều khiển in.

* Trước khi cài đặt trình điều khiển in trong môi trường cụm của Windows, bạn cần
  cài đặt trình điều khiển trên mỗi nút trong cụm.

---------------------------------------------------
4. LƯU Ý VÀ GIỚI HẠN
---------------------------------------------------
* Khi chỉ định màu giấy từ trình điều khiển, hãy sử dụng ROM điều khiển mới nhất. 

* Có thể cần cập nhật ApeosWare Management Suite 2 khi bạn dùng trình điều khiển
  này kết hợp với ApeosWare Management Suite 2. Vui lòng xem thêm thông tin hỗ
  trợ hoặc trang web chính thức của chúng tôi về ApeosWare Management Suite 2.

* Khi theo dõi các công việc in bằng trình điều khiển này, hãy sử dụng Fujifilm Document Monitor phiên bản 2 hoặc mới hơn.

* Về [Ưu tiên màu đã xác định trong ứng dụng khi Màu giấy ra
  là Đen trắng]
  Đối với kết quả in phù hợp với thiết đặt màu được
  xác định bởi giao diện người dùng của ứng dụng,
  đặt [In sử dụng màu đã xác định trong ứng dụng]
  và [Ưu tiên màu đã xác định trong ứng dụng khi
  Màu giấy ra là Đen trắng] thành [Bật].

  Diễn giải sau mô tả liên hệ giữa thiết đặt của
  trình điều khiển máy in ([Màu giấy ra], [In sử dụng
  màu đã xác định trong ứng dụng] và [Ưu tiên
  màu đã xác định trong ứng dụng khi Màu giấy ra
  là Đen trắng]) và kết quả in.

  * [In sử dụng màu đã xác định trong ứng dụng]: [Tắt]
    Màu giấy ra được xác định bởi ứng dụng sẽ bị bỏ qua
    và thiết đặt [Màu giấy ra] trên giao diện người dùng của
    trình điều khiển sẽ được sử dụng để in.

  * [In sử dụng màu đã xác định trong ứng dụng]: [Bật]
    - [Ưu tiên màu đã xác định trong ứng dụng khi
      Màu giấy ra là Đen trắng]: [Bật]
      Màu giấy ra được xác định bởi ứng dụng sẽ được sử dụng
      để in. Nếu không có Màu giấy ra được xác định bởi
      ứng dụng, thiết đặt [Màu giấy ra] trên giao diện người dùng
      của trình điều khiển sẽ được sử dụng để in.

    - [Ưu tiên màu đã xác định trong ứng dụng khi Màu giấy ra
      là Đen trắng]: [Tắt]
      Nếu thiết đặt [Màu giấy ra] trên giao diện người dùng
      của trình điều khiển là [Màu], Màu giấy ra được
      xác định bởi ứng dụng sẽ được sử dụng để in.
      Nếu thiết đặt [Màu giấy ra] trên giao diện người dùng
      của trình điều khiển là [Đen trắng], Màu giấy ra được
      xác định bởi ứng dụng sẽ bị bỏ qua và kết quả in
      sẽ là đen trắng. Nếu không có Màu giấy ra được
      xác định bởi ứng dụng, thiết đặt [Màu giấy ra] trên
      giao diện người dùng của trình điều khiển sẽ được
      sử dụng để in.

*Về việc sử dụng máy in dùng chung
  Nếu bạn gặp phải vấn đề như dưới đây khi sử dụng máy in dùng chung, bạn có thể sửa để in lại đúng ý bằng cách thay đổi giá trị trong [Kết xuất tác vụ in trên máy tính khách].
  - Chú thích hoặc phần in chìm không được in đúng cách, kể cả khi đã chỉ định.
  - Thiết đặt xác thực chưa được thể hiện đúng, hoặc cửa sổ bật lên yêu cầu xác thực không hiện ra.

* Giới hạn chức năng của Cuộn dữ liệu EMF
  Khi [Cuộn dữ liệu EMF] ở tab [Thiết đặt nâng cao] được đặt thành [Bật],
  các tính năng sau có thể không hoạt động như thường lệ.
  Để sử dụng các tính năng này, đặt [Cuộn dữ liệu EMF] sang [Tắt].
  - [In bảo mật][Bộ mẫu][In hẹn giờ]
  - [Bật thiết lập tài khoản][Thiết lập chi tiết người dùng]
  - [Thông báo hoàn thành công việc bằng E-mail]
  - [Chú thích]
  - [Chèn trang phân tách] của [Bìa / Trang phân tách]
  - [Sử dụng tính năng mở rộng từ ứng dụng]

* Chọn một máy in từ thư mục [Thiết bị và Máy in]. Chọn Thuộc tính của
  máy in và nhấp vào nút [Thay đổi tùy chọn chia sẻ] trên tab [Chia sẻ].
  Sau đó, chỉ định Khổ giấy tùy chỉnh.

* Độ phân giải mặc định của trình điều khiển này là 600dpi. (Được tự động thể hiện)
  Khi thực hiện công việc qua một trình điều khiển có độ phân giải khác với
  độ phân giải của trình điều khiển này, có thể có các lỗi như sau tùy vào
  thông số kỹ thuật hoặc giới hạn của một ứng dụng.

  - Bố cục in của tài liệu bị thay đổi.
  - Kết quả in của các đường kẻ hoặc mẫu hình bị thay đổi.
  - Các đường kẻ không cần thiết có thể được in trên giấy ra.
  - Các đường kẻ cần thiết không được in trên giấy ra.

  Trong những trường hợp như thế, có thể cải thiện tình trạng bằng cách
  thay đổi thiết đặt của [Độ phân giải] trong tab [Nâng cao].

* Bố cục in có thể sẽ bị thay đổi khi bạn thay đổi [Chất lượng hình ảnh]
  trong tab [Tùy chọn màu].

* Tùy thuộc vào ứng dụng, nếu độ phân giải của trình điều khiển
  cao, kích thước của dữ liệu in có thể sẽ lớn và quá trình in
  không thể được thực hiện đúng cách. Khi tình trạng này xảy ra,
  hãy xác định các thiết đặt sau:
  - Xác định [Độ phân giải] trong nhóm [Tùy chọn hình ảnh] trong
    tab [Nâng cao] thành [300dpi] hoặc [200dpi].

* Đối với một số ứng dụng, nếu hình ảnh được dán được in
  với độ phân giải cao, dữ liệu in sẽ mở rộng và có thể khiến
  tốc độ in cực kỳ chậm.
  Bạn có thể cải thiện kích thước dữ liệu in của giấy ra bằng cách
  thay đổi thiết đặt sau cho nhóm [Tùy chọn hình ảnh] trong tab [Nâng cao].
  - Xác định [Nén ảnh] thành [Tiêu chuẩn] hoặc [Ảnh] hoặc
   [Độ phân giải] thành [300dpi] hoặc [200dpi]

* Khi in từ ứng dụng của QuarkXpress 6.1E, nếu thiết đặt
  [Chất lượng hình ảnh] là [Độ phân giải cao] và độ phân giải
  của trình điều khiển là [1200dpi], tài liệu có thể được in thành
  các trang trống.  Vấn đề này có thể tránh được bằng cách thay đổi
  độ phân giải của trình điều khiển thành [Tự động].

* Khi thực hiện công việc in bằng cách chỉ định Nguồn giấy thành Tự động,
  hãy đảm bảo đặt Khổ giấy trong ứng dụng thành Khổ giấy mà trình
  điều khiển có hỗ trợ để bật tính năng nạp giấy tự động.

* Khi sử dụng tính năng Phủ chờm mẫu, hãy sử dụng
  dữ liệu mẫu của Nguồn giấy, Độ phân giải và Thiết đặt
  hình ảnh giống như của tài liệu mà bạn muốn in.  Nếu những thiết đặt này
  khác nhau giữa dữ liệu mẫu và trang có chứa dữ liệu mẫu,
  bạn có thể sẽ không nhận được kết quả in mong đợi.

* Khi sử dụng Phủ chờm mẫu, do một số ứng dụng đặt nền là màu trắng
  khi in, các mẫu chồng lấp có thể sẽ bị ẩn.  Các ứng dụng như thế
  bao gồm PowerPoint và WordPad.

* Kết quả in có thể sẽ chồng lấp nếu chọn Nhiều trang trên một tờ (N trang trên một tờ)
  và Lề [Tiêu chuẩn] khi in một tài liệu vượt quá giới hạn vùng in của trình điều khiển in.
  Nếu tình trạng này xảy ra, hãy chọn [Không có] cho nhóm nút chọn một của
  [Lề] trong tab [Tùy chọn hình ảnh].

* Để sử dụng tính năng [Lưu trữ trong thư mục từ xa],
  bạn phải có trước số thư mục của người nhận đã được đăng ký và mật mã.
  Tham khảo hướng dẫn cho quản trị viên của máy về cách tạo thư mục.

- Tuỳ thuộc vào ứng dụng được khách hàng sử dụng, các trang trống dùng để điều
  chỉnh trang sẽ được chèn tự động, tuỳ thuộc vào các điều kiện như số bản sao
  được chỉ định khi cho ra bản in 2 mặt.
  Trong trường hợp ấy, các trang trống được chèn sẽ được thêm vào bởi ứng dụng.
  Hiệu năng sẽ được cải thiện bằng cách thay đổi thiết đặt dưới đây.
  - Đặt [Bỏ qua trang trống] tại thẻ [Nâng cao] thành [Bật].

* Cho dù đã chọn [Bỏ qua trang trống], các trang trống
  có thể vẫn sẽ được in trong các tình huống sau.
  - Trang chỉ chứa các ký tự nhảy dòng.
  - Trang chỉ chứa các khoảng trắng.
  - Trang chỉ chứa các ký tự nhảy dòng và các khoảng trắng.
  - Chỉ thị vẽ nền trắng được gửi từ ứng dụng.

* Với Microsoft Word, cho dù đã chọn [Bỏ qua trang trống],
  khi một trang trống được nạp kèm trong tài liệu, trang trống
  vẫn có thể được in ra.

* Nút [Hủy bỏ] trong hộp thoại [Thiết lập chi tiết người dùng]
  Đối với một số ứng dụng, nếu hộp thoại [Nhập chi tiết người dùng]
  bị hủy bỏ khi đang in với thiết đặt của [Nhắc người dùng về mục nhập
  khi gửi công việc] trong hộp thoại [Thiết lập chi tiết người dùng],
  một hộp thoại cảnh báo có thể sẽ xuất hiện.
  Hộp thoại cảnh báo này có thể cho biết có lỗi máy in,
  tuy nhiên, máy in thực ra không có vấn đề gì.

  Trong trường hợp đó, hãy bỏ qua cảnh báo và tiếp tục.

* Khi [Cuộn dữ liệu EMF] trong tab [Nâng cao] được đặt thành [Đã tắt],
  một số tài liệu có cấu trúc phức tạp có thể sẽ gặp vấn đề như
  hình ảnh đầu ra bị biến dạng hoặc hỏng kết quả in ra.

* Để thay đổi thiết đặt của Kích thước giấy tùy chỉnh, bạn cần quyền truy cập Quản trị viên. 
  Chọn máy in từ thư mục máy in, bấm chuột phải để chọn [Chạy với tư cách quản trị viên] và chọn [Thuộc tính].
  Sau khi nhấp vào [Tiếp tục] trong [Kiểm soát Tài khoản Người dùng], 
  bạn có thể thay đổi các cài đặt từ Thuộc tính.

  Khi Kích thước giấy tùy chỉnh bằng kích thước giấy tiêu chuẩn được chỉ định trong phần Khổ giấy, 
  công việc in có thể được thực hiện như thể đã chỉ định khổ giấy [tiêu chuẩn].
  Để chọn đầu ra là Kích thước giấy tùy chỉnh, 
  hãy chỉ rõ Kích thước giấy tùy chỉnh trong Kích thước đầu ra.

* Với thiết đặt mặc định của Tường lửa, dữ liệu
  trong phát đa hướng mạng con chéo
  không thể được truy xuất. Để truy xuất dữ liệu
  mạng con chéo, vui lòng không sử dụng
  phát đa hướng và xác định địa chỉ trực tiếp.

* Lưu ý và hạn chế về môi trường máy chủ-máy khách
- Lỗi môi trường máy chủ-máy khách (1)
  Nếu máy in đang được dùng làm máy in được chia sẻ, và hệ điều hành của máy 
  chủ đang được nâng cấp, sẽ có thể có một thông báo cho biết trình điều 
  khiển cần phải được cập nhật xuất hiện trên máy khách, khiến việc in bị thất bại.
  Trong trường hợp này, cần phải cài lại trình điều khiển máy in trên máy khách 
  để có thể in lại được.

- Lỗi môi trường máy chủ-máy khách (2)
  Trong môi trường Máy chủ - Máy khách, sau khi thêm hoặc nâng cấp
  một trình điều khiển in trên máy chủ, quá trình in có thể sẽ không
  thực hiện được và một thông báo xuất hiện yêu cầu nâng cấp
  trình điều khiển in bên phía máy khách.
  Bạn có thể tránh vấn đề này với thiết đặt dưới đây.

  <Thay đổi Thiết đặt chính sách nhóm trên Máy khách>
  1. Đăng nhập với vai trò Người quản trị trên Máy khách.
  2. Mở dấu nhắc lệnh và thực hiện lệnh "gpedit.msc" để mở [Local Group Policy Editor].
  3. Mở cây ở phía bên trái theo thứ tự như sau.
     [User Configuration]
     [Administrative Templates]
     [Control Panel]
     [Printers]
  4. Nhấp đúp vào [Point and Print Restrictions] trong ngăn bên phải.
  5. Nhấp vào nút chọn [Disabled].
  6. Nhấp [OK] để đóng cửa sổ.
  7. Đóng [Local Group Policy Editor].

* Hạn chế khi in với thiết đặt của Dập ghim và Dập lỗ cùng lúc.
  Dập ghim và Dập lỗ có thể sẽ không hoạt động khi chọn
  1 ghim và Dập lỗ cùng lúc đối với một số khổ giấy.

* Thiết đặt màu giấy ra từ ứng dụng
  Để in màu từ ứng dụng của Windows Store, mở mục
  [Thiết bị và máy in] từ Bàn làm việc của Windows, nhấp
  chuột phải vào máy in để chọn [Tùy chọn in] sau đó
  xác nhận rằng [Màu giấy ra] trong tab [Giấy/Giấy ra]
  của hộp thoại [Tùy chọn in] được đặt thành [Màu].
  Nếu thiết đặt [Màu giấy ra] trong tab [Giấy/Giấy ra]
  của hộp thoại [Tùy chọn in] vẫn là [Trắng đen], màu in ra
  sẽ vẫn là trắng đen cho dù bạn chỉ định Chế độ màu là
  [Màu] trên màn hình thiết đặt in được hiển thị sau khi
  bạn chọn máy in từ nút thiết bị.

* Microsoft Outlook
  Khi in Lịch biểu, nội dung in màu có thể sẽ in ra đen trắng và bị mất màu.
  Nếu hộp mực được sử dụng để in ra giống như màu xám, bộ đếm sẽ tính
  công việc đó là in màu.
 
  Trong những trường hợp đó, có thể tránh lỗi bằng phương pháp sau.
  1. Đóng Outlook.
  2. Bấm chuột phải vào biểu tượng máy in trong [Thiết bị và Máy in] và mở [Tùy chọn in].
  3. Bấm nút [OK] để đóng [Tùy chọn in].

  Khi sử dụng biểu tượng máy in được chia sẻ, một người dùng mới của máy in
  được chia sẻ có thể tránh lỗi trên bằng phương pháp sau. (Chỉ người quản trị
  được phép thực hiện.)
  1. Bấm chuột phải vào biểu tượng máy in trong [Thiết bị và Máy in]
       và mở [Thuộc tính Máy in].
  2. Đến tab [Nâng cao] và mở [Mặc định in].
  3. Bấm nút [OK] để đóng [Mặc định in].
  4. Đóng [Thuộc tính Máy in].

---------------------------------------------------
5. Cập nhật phần mềm
---------------------------------------------------
    Phần mềm mới nhất có sẵn trên trang web của chúng tôi.

        https://fujifilm.com/fbglobal

    Phí liên lạc sẽ do khách hàng thanh toán.

--------------------------------------------------------------------------------
Microsoft và Windows là các thương hiệu đã đăng ký của Microsoft Incorporated.
Các tên sản phẩm và tên công ty khác là thương hiệu hoặc
thương hiệu đã đăng ký của từng công ty tương ứng.

Adobe, Acrobat và Reader là thương hiệu hoặc thương hiệu đã được đăng ký của
Adobe tại Hoa Kỳ và/hoặc các quốc gia khác.

ApeosWare là một thương hiệu đã đăng ký của Công ty FUJIFILM Business Innovation
Corp.

Các tên sản phẩm và tên công ty khác là thương hiệu hoặc
thương hiệu đã đăng ký của từng công ty tương ứng.

libjpeg 6b
----------
This software is based in part on the work of the Independent JPEG Group.

(C) FUJIFILM Business Innovation Corp. 2018-2023
