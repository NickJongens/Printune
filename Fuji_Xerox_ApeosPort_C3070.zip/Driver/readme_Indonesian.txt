================================================================================
Kesepakatan Lisensi
================================================================================

Kesepakatan lisensi untuk perangkat lunak ini (selanjutnya disebut sebagai
PERANGKAT LUNAK) dapat dijelaskan sebagai berikut.

1 Hak kekayaan intelektual dalam PERANGKAT LUNAK tetap dimiliki oleh
   FUJIFILM Business Innovation Corp. (Selanjutnya disebut sebagai
   FUJIFILM Business Innovation) demikian juga sebagai pemegang hak cipta aslinya.

2 PERANGKAT LUNAK hanya boleh digunakan dengan produk yang kompatibel dengan
   FUJIFILM Business Innovation (selanjutnya disebut sebagai PRODUK KOMPATIBEL)
   di negara tempat PRODUK KOMPATIBEL tersebut dibeli.

3 Anda diminta mematuhi catatan dan pembatasan ini (selanjutnya disebut sebagai
   CATATAN DAN PEMBATASAN) yang dinyatakan oleh FUJIFILM Business Innovation 
   selama Anda menggunakan PERANGKAT LUNAK.

4 Anda tidak diizinkan untuk mengubah, memodifikasi, merekayasa balik,
   mendekompilasi atau membongkar seluruh atau sebagian PERANGKAT LUNAK
   untuk tujuan menganalisis PERANGKAT LUNAK.

5 Anda tidak diizinkan mendistribusikan PERANGKAT LUNAK kepada jaringan
   komunikasi, atau mentransfer, menjual, menyewakan atau melisensikan
   PERANGKAT LUNAK kepada pihak ketiga dengan menduplikasi PERANGKAT LUNAK
   pada media apa pun seperti floppy disk atau pita magnetik.

6 FUJIFILM Business Innovation, Mitra Saluran FUJIFILM Business Innovation,
   Dealer Resmi dan pemegang asli hak cipta
   PERANGKAT LUNAK tidak bertanggung jawab atas kehilangan atau kerusakan
   yang timbul akibat pencocokan perangkat keras atau program yang tidak
   ditentukan dalam CATATAN DAN PEMBATASAN PERANGKAT LUNAK,
   atau modifikasi pada PERANGKAT LUNAK.

7 FUJIFILM Business Innovation, Mitra Saluran FUJIFILM Business Innovation,
   Dealer Resmi dan pemegang asli hak cipta 
   PERANGKAT LUNAK tidak bertanggung jawab atas garansi atau tanggung jawab apa 
   pun sehubungan dengan PERANGKAT LUNAK.

================================================================================
PCL 6 Print Driver Ver.6.13.5 Tambahan Informasi
================================================================================

Dokumen ini memberikan informasi tentang  pada
item-item berikut:

1. Produk Perangkat Keras Target
2. Persyaratan
3. Komentar Umum
4. CATATAN DAN PEMBATASAN
5. Perbarui Perangkat Lunak

---------------------------------------------------
1. Produk Perangkat Keras Target
---------------------------------------------------
ApeosPort C7070
ApeosPort C6570
ApeosPort C5570
ApeosPort C4570
ApeosPort C3570
ApeosPort C3070

---------------------------------------------------
2. Persyaratan
---------------------------------------------------
Harap dicatat bahwa driver ini beroperasi pada komputer yang menjalankan
sistem operasi berikut ini.

  Microsoft(R) Windows(R) 10 x64 Editions
  Microsoft(R) Windows Server(R) 2016
  Microsoft(R) Windows Server(R) 2019
  Microsoft(R) Windows(R) 11
  Microsoft(R) Windows Server(R) 2022

  Kunjungi situs web kami untuk memeriksa perangkat lunak
  terbaru dan sistem operasi yang didukung.

* Sama dengan perubahan nama perusahaan.
  Pengaturan driver tidak dapat diambil alih karena Anda tidak dapat meningkatkan
  driver dari driver dengan nama lama perusahaan. Instal bersih versi baru.

 
---------------------------------------------------
3. Komentar Umum
---------------------------------------------------
* Tutup semua aplikasi yang dijalankan sebelum menginstal driver cetak.

* Selalu nyalakan ulang komputer setelah menginstal versi driver cetak
  yang diperbarui.

* Jika Anda telah menghapus versi driver cetak yang lama, selalu nyalakan
  ulang komputer sebelum menginstal versi yang baru.

* Beberapa aplikasi menyediakan opsi pencetakan terkait dengan jumlah
  salinan dan salinan kolase. Selalu pilih opsi pencetakan dalam aplikasi
  kecuali instruksi menentukan lain. Gunakan dialog driver cetak untuk
  memilih opsi lanjutan seperti Cetak 2 Sisi, Set Contoh, atau opsi yang
  tidak tersedia dalam aplikasi.

* Selalu tutup dialog driver cetak dan/atau kotak dialog Cetak aplikasi
  sebelum Anda melakukan perubahan pada pengaturan standar
  driver cetak melalui Panel Kontrol.

* Jika output Offset Pekerjaan Anda tidak bekerja dengan baik pada salinan
  kolase, cobalah untuk membatalkan pilihan opsi [Kolase] dalam aplikasi
  dan menandai kotak centang [Kolase] dalam driver cetak.

* Jika Buku Telepon Faks tidak diinisialisasi atau dibuat oleh pengguna saat ini,
  dia mungkin tidak diberikan wewenang untuk mengaksesnya. Untuk akses
  yang tidak patut oleh pengguna, driver akan menampilkan pesan kesalahan
  yang menunjukkan bahwa default Buku Telepon Faks tidak dapat ditemukan
  atau Buku Telepon Faks yang ditentukan tidak dapat dikenali.
  Di sisi lain, jika pengguna ingin Buku Telepon Faksnya diakses oleh pengguna
  lain, ia harus menentukan grup dan pengguna yang aksesnya dia izinkan, dan
  harus memberi mereka setidaknya izin 'Ubah' ke file data
  Buku Telepon Faks.

* Pekerjaan faks harus dikirim secara terpisah ke setiap penerima yang
  ditentukan dengan kode-F, Kata Sandi atau atribut pengiriman aman.
  Jika tidak, printer selalu mengabaikan kode-F, Kata Sandi dan pengiriman
  aman atribut saat mengirim pekerjaan faks ke beberapa penerima. Pekerjaan
  yang ditransmisikan selalu dicetak langsung di semua tujuan yang ditentukan.

* Untuk pemasangan melalui jaringan, jika Anda mengklik kanan
  pada folder [Printer], buka [Jalankan sebagai administrator] dari menu dan pilih
  [Tambah printer ...], ikon printer mungkin tidak dihasilkan.

* Penggantian nama Ikon Printer harus mematuhi konvensi penamaan file OS.
  Penggunaan Simbol atau karakter khusus dapat menyebabkan kesalahan
  penggantian nama atau perilaku driver cetak yang tidak terduga.

* Sebelum menginstal driver cetak di lingkungan cluster Windows, Anda perlu
  menginstalnya pada setiap node di cluster.

---------------------------------------------------
4. CATATAN DAN PEMBATASAN
---------------------------------------------------
* Saat menentukan warna kertas dari driver, gunakan ROM pengontrol terbaru. 

* Anda mungkin perlu meningkatkan ApeosWare Management Suite 2 saat menggunakan
  driver ini bersama aplikasi tersebut. Lihat situs resmi/informasi dukungan
  untuk ApeosWare Management Suite 2.

* Saat memonitor pekerjaan cetak dengan driver ini, gunakan Fujifilm Document Monitor ver. 2 ke atas.

* Tentang [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]
  Untuk hasil cetak yang konsisten dengan pengaturan warna yang ditentukan oleh
  UI aplikasi, atur [Cetak Menggunakan Warna Tertentu Aplikasi] dan [Prioritaskan
  Warna Tertentu Aplikasi saat Warna Output Hitam Putih] ke [On].

  Berikut ini menjelaskan hubungan antara pengaturan driver printer ([Warna Output],
  [Cetak Menggunakan Warna Tertentu Aplikasi], dan [Prioritaskan Warna Tertentu
  Aplikasi saat Warna Output Hitam Putih]), dan output cetak.

  * [Cetak Menggunakan Warna Tertentu Aplikasi]: [Off]
    Warna Output yang ditentukan oleh aplikasi akan diabaikan, dan pengaturan
    [Warna Output] UI driver akan digunakan untuk mencetak.

  * [Cetak Menggunakan Warna Tertentu Aplikasi]: [On]
    - [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]: [On]
      Warna Output yang ditentukan oleh aplikasi akan digunakan untuk mencetak.
      Jika tidak ada Warna Output ditentukan oleh aplikasi, pengaturan [Warna Output]
      driver UI akan digunakan untuk mencetak.

    - [Prioritaskan Warna Tertentu Aplikasi saat Warna Output Hitam Putih]: [Off]
      Jika pengaturan [Warna Output] driver UI adalah [Warna], Warna Output yang
      ditentukan oleh aplikasi akan digunakan untuk mencetak.
      Jika pengaturan [Warna Output] driver UI adalah [Hitam Putih], Warna Output
      ditentukan oleh aplikasi akan diabaikan, dan hasil cetak akan menjadi hitam putih.
      Jika tidak ada Warna Output ditentukan oleh aplikasi, pengaturan [Warna Output]
      driver UI akan digunakan untuk mencetak.

*Tentang penggunaan printer bersama
  Kerusakan cetakan yang terjadi di dalam lingkungan printer bersama dapat diperbaiki dengan mengubah nilai [Lakukan pekerjaan cetak pada komputer klien].
  - Anotasi/Watermark tidak tercetak dengan baik, bahkan saat pengaturan berikut dipilih.
  - Pengaturan autentikasi tidak terefleksikan dengan baik, atau pesan autentikasi tidak muncul.

* Pembatasan fungsional Spooling EMF
  Ketika [Spooling EMF] tab [Pengaturan Tingkat Lanjut] diatur
  ke [Aktif], fitur berikut ini mungkin tidak berfungsi dengan normal.
  Untuk menggunakan fitur ini, atur [Spooling EMF] ke [Nonaktif].
  - [Cetak Aman][Set Contoh][Cetak Tertunda]
  - [Aktifkan Penyetelan Akun][Penyetelan Detail Pengguna]
  - [Beritahukan Pekerjaan Selesai melalui Email]
  - [Anotasi]
  - [Sisipkan Pemisah] [Sampul/Pemisah]
  - [Gunakan Fitur Perpanjangan Dari Aplikasi]

* Pilih printer dari folder [Perangkat dan Printer]. Pilih Properti 
 printer lalu klik tombol [Ubah Opsi Berbagi] pada tab [Berbagi] .
 Selanjutnya, pilih Ukuran Kertas Khusus.

* Resolusi default driver ini adalah% DefaultResolution%. (Ditunjukkan Otomatis.)
  Saat mengeluarkan melalui driver, resolusi yang berbeda dari salah satu driver ini,
  kesalahan seperti berikut dapat diamati tergantung pada spesifikasi atau batasan
  aplikasi.
  - Tata letak dokumen dicetak diubah.
  - Hasil cetak dari garis atau pola diubah.
  - Garis yang tidak perlu dicetak pada output.
  - Garis yang diperlukan tidak dicetak pada output.

  Dalam kasus seperti itu, status dapat ditingkatkan dengan mengubah
  pengaturan [Resolusi] pada tab [Tingkat Lanjut].

* Tata letak cetak mungkin berubah ketika Anda mengubah [Kualitas Gambar]
  di tab [Opsi Warna].

* Tergantung pada aplikasinya, jika resolusi driver tinggi, maka ukuran data
  cetak mungkin menjadi sangat besar dan pencetakan tidak dapat dilakukan
  dengan benar. Ketika ini terjadi, tentukan pengaturan berikut:
  - Tentukan [Resolusi] di grup [Opsi Gambar] di tab [Tingkat Lanjut]
    ke [300 dpi] atau [200 dpi].

* Untuk beberapa aplikasi, jika gambar yang ditempel dicetak pada resolusi tinggi,
  data cetak meluas dan dapat mengakibatkan kecepatan cetak yang sangat lambat.
  Ukuran data cetak dari output dapat ditingkatkan dengan mengubah pengaturan
  grup [Opsi Gambar] yang berikut ini pada tab [Tingkat Lanjut].
  - Tentukan [Kompresi Gambar] ke [Standar] atau [Foto] atau [Resolusi] untuk
    [300 dpi] atau [200 dpi].

* Saat mencetak dari aplikasi QuarkXPress 6.1E, jika pengaturan [Kualitas Gambar]
  adalah [Resolusi Tinggi] dan resolusi driver adalah [1200 dpi], dokumen dapat
  dicetak sebagai halaman kosong. Masalah ini dapat dihindari dengan mengubah
  resolusi driver ke [Otomatis].

* Saat melakukan pekerjaan cetak dengan menetapkan Sumber Kertas sebagai
  Otomatis, pastikan untuk mengatur Ukuran Kertas dalam aplikasi ke Ukuran
  Kertas yang didukung driver untuk mengaktifkan fitur pengumpanan kertas otomatis.

* Saat menggunakan fitur Hamparkan Formulir, gunakan data formulir dengan
  Ukuran Kertas yang sama, Resolusi, dan Pengaturan Gambar seperti pada
  dokumen yang ingin Anda cetak. Jika pengaturan ini berbeda antara data
  formulir dan halaman tempat data formulir dimasukkan, hasil cetak yang
  diharapkan mungkin tidak diperoleh.

* Saat menggunakan Hamparkan Formulir, karena beberapa aplikasi mengecat
  latar belakang dengan warna putih untuk mencetak, formulir dengan overlay
  mungkin disembunyikan. Aplikasi tersebut termasuk PowerPoint dan WordPad.

* Hasil cetak mungkin tumpang tindih jika Halaman Per Lembar (N-Up) dan
  Margin [Standar] dipilih saat mencetak dokumen yang telah melebihi area
  cetak driver cetak. Ketika ini terjadi, pilih [Tidak Ada] dari grup tombol radio
  [Margin] pada tab [Opsi Gambar].

* Saat Anda membatalkan pekerjaan faks yang sedang berlangsung dari driver,
  aplikasi mungkin menampilkan kotak dialog peringatan. Ini mungkin
  menunjukkan pesan kesalahan printer,meskipun tidak ada kesalahan pada
  printer. Dalam hal ini, abaikan pesan peringatan itu dan lanjutkan operasi.

* Untuk menggunakan fitur [Simpan di Folder Jarak Jauh], Anda harus mendapatkan
  nomor folder dan kode sandi penerima yang sebelumnya sudah terdaftar.
  Lihat panduan administrator mesin tentang cara membuat folder.

- Tergantung aplikasi yang digunakan oleh konsumen, halaman kosong untuk
  penyesuaian halaman akan disisipkan secara otomatis berdasarkan kondisi
  seperti jumlah salinan yang dipilih saat meng-output cetak 2 sisi.
  Di sini, sisipan kosong akan disertakan dalam aplikasi.
  Performa diperbaiki dengan mengubah pengaturan di bawah.
  - Atur [Lompati Halaman Kosong] pada tab [Lanjutan] ke [On].

* Bahkan dengan [Lompati Halaman Kosong] dipilih, halaman kosong mungkin
  masih dicetak dalam situasi berikut.
  - Halaman ini hanya berisi umpan baris.
  - Halaman ini hanya berisi spasi.
  - Halaman ini hanya berisi feed dan spasi baris.
  - Instruksi gambar latar belakang putih dikirim dari aplikasi.

* Dengan Microsoft Word, bahkan jika [Lompati Halaman Kosong] ditentukan,
  saat kosong halaman disertakan dalam dokumen, mungkin itu output.

* Tombol [Batal] pada Dialog [Pengaturan Detail Pengguna]
  Untuk beberapa aplikasi, jika dialog [Masukkan Detail Pengguna] dibatalkan saat
  mencetak dengan pengaturan [Minta Pengguna untuk Masuk saat Mengirim pekerjaan]
  pada dialog [Pengaturan Detail Pengguna], dialog peringatan dapat ditampilkan.
  Dialog peringatan ini dapat mengindikasikan kesalahan printer, tetapi
  sebenarnya printer tidak ada masalah.

  Dalam hal ini, abaikan peringatan dan lanjutkan.

* Ketika [Spool EMF] dari tab [Tingkat Lanjut] diatur ke [Nonaktif], beberapa
  dokumen dengan struktur yang kompleks mungkin memiliki masalah seperti gambar
  output terdistorsi dan kegagalan output.

* Dengan pengaturan default Firewall, data dalam siaran lintas-subnet tidak
  dapat  diambil.
  Untuk pengambilan data lintas-subnet, harap jangan gunakan siaran dan
  tentukan alamat langsung.

* Catatan dan batasan tentang lingkungan server-klien
- Masalah Lingkungan Server-Klien (1)
  Jika printer sedang digunakan sebagai printer bersama dan operasi server
  sistem sedang ditingkatkan, pesan yang menunjukkan bahwa driver harus
  diperbarui dapat muncul pada klien, menyebabkan pencetakan gagal.
  Dalam hal ini, driver cetak harus diinstal ulang pada klien supaya dapat
  mencetak lagi.

- Masalah Lingkungan Server-Klien (2)
  Di lingkungan Server-Client, setelah driver cetak ditambahkan atau
  ditingkatkan di sisi Server, pencetakan mungkin tidak dilakukan dengan
  pesan yang ditampilkan membutuhkan peningkatan driver cetak di sisi Klien.
  Masalah ini dapat dihindari dengan pengaturan di bawah ini.

  < Ubah Pengaturan Kebijakan Grup pada PC Klien >
  1. Masuk sebagai Administrator pada PC Klien.
  2. Buka perintah prompt dan lakukan "gpedit.msc". Untuk membuka [Editor
     Kebijakan Grup Lokal].
  3. Buka pohon di sebelah kiri dengan urutan berikut ini.
     [Konfigurasi Pengguna]
     [Templat Administratif]
     [Panel Kontrol]
     [Printer]
  4. Klik dua kali [Tunjuk dan Cetak Batasan] di panel kanan.
  5. Klik tombol radio [Nonaktif].
  6. Klik [OK] untuk menutup jendela.
  7. Tutup [Editor Kebijakan Grup Lokal].

* Batasan pada pencetakan dengan pengaturan Staple dan Berlubang
  secara bersamaan waktunya
  Staple dan Berlubang mungkin tidak berfungsi saat 1 Staple dan Berlubang
  sedang ditentukan secara bersamaan untuk beberapa ukuran kertas.

* Pengaturan Warna Output dari Aplikasi
  Untuk mencetak warna dari Aplikasi Windows Store, buka [Peranti dan Pencetak]
  dari Windows Desktop, klik kanan pada printer Anda untuk memilih [Preferensi
  Pencetakan] dan kemudian konfirmasikan bahwa [Warna Output] pada tab
  [Kertas/Output] pada dialog [Preferensi Pencetakan] diatur ke [Warna].
  Jika pengaturan [Warna Output] pada tab [Kertas/Output] pada dialog [Preferensi
  Pencetakan] tetap [Hitam Putih], output akan berwarna hitam dan putih bahkan jika
  Anda menentukan Mode Berwarna ke [Warna] pada layar pengaturan pencetakan
  ditampilkan setelah Anda memilih printer dari pesona perangkat.

* Keterbatasan pada Adobe Acrobat / Reader
  Saat Anda menentukan [2] atau lebih banyak halaman untuk [Salinan] pada dialog
  [Cetak] dari Adobe Acrobat/Reader, Faks mungkin tidak dikirim secara normal.

* Microsoft Outlook
  Saat mencetak Jadwal, bagian-bagian yang akan dicetak berwarna mungkin
  tampak dicetak dalam warna hitam dan putih dengan warna yang hilang.
  Jika toner warna digunakan untuk membuatnya tampak seperti abu-abu,
  pengukur akan menghitung pekerjaan itu sebagai pencetakan berwarna.
 
  Dalam kasus seperti itu, masalahnya dapat dihindari dengan metode berikut.
  1. Tutup Outlook.
  2. Klik kanan ikon printer di [Peranti dan Pencetak], dan buka [Mencetak
     preferensi].
  3. Klik tombol [OK] untuk menutup [Preferensi pencetakan].

  Dalam hal menggunakan ikon printer bersama, pengguna baru printer
  bersama dapat menghindari masalah dengan metode berikut. (Hanya
  administrator yang diizinkan untuk melakukan.)
  1. Klik kanan ikon printer di [Peranti dan Pencetak] dan buka [Properti
     printer].
  2. Buka tab [Tingkat Lanjut], lalu buka [Default Pencetakan].
  3. Klik tombol [OK] untuk menutup [Default Pencetakan].
  4. Tutup [Properti printer].

* Batasan pada pencetakan dengan pengaturan [Amplop] untuk [Tipe Kertas]
  Saat mencetak dengan pengaturan [Amplop] untuk [Tipe Kertas] atau [Tipe],
  pekerjaan cetak mungkin tidak dilakukan dengan benar.
  Untuk mencetak pada kertas jenis amplop, buka kotak dialog [Pemilihan
  Kertas Tingkat Lanjut], atur [Baki Kertas] ke [Baki 5 (Bypass)] lalu atur
  [Tipe Kertas Bypass] ke [Amplop].

---------------------------------------------------
5. Perbarui Perangkat Lunak
---------------------------------------------------
    Perangkat lunak terkini tersedia di situs web kami.

        https://fujifilm.com/fbglobal

    Biaya komunikasi menjadi tanggungan pelanggan.

--------------------------------------------------------------------------------
Microsoft, Windows, Windows Server, Word, Excel, PowerPoint,
Microsoft Edge, Outlook dan Visio adalah merek dagang teregistrasi atau merek
dagang milik Microsoft Corporation di Amerika Serikat dan/atau negara lainnya.

Adobe, Acrobat, dan Reader adalah merek dagang terdaftar atau merek dagang
teregistrasi atau merek dagang milik Adobe di Amerika Serikat
dan/atau negara-negara lain.

ApeosWare adalah merek dagang terdaftar milik FUJIFILM Business Innovation Corp.

Nama perusahaan dan nama produk lain adalah merek dagang atau merek
dagang teregistrasi milik perusahaan-perusahaan terkait.

libjpeg 6b
----------
This software is based in part on the work of the Independent JPEG Group.

(C) FUJIFILM Business Innovation Corp. 2020-2023
